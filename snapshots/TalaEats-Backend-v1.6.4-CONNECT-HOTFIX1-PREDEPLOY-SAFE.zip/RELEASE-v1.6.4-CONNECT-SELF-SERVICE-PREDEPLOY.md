# TALA EATS Backend v1.6.4 — Stripe Connect Self-Service

Based on v1.6.3 HF4; no data migrations.

New authenticated endpoints:
- POST `/api/v1/withdrawals/{restaurant|driver}/{recipient_id}/connect/onboarding`: create/reuse Stripe Connect Express account for owner and issue one-use Stripe onboarding URL or Express login link.
- GET `/api/v1/withdrawals/{role}/{id}/connect/status`: verify connected account at Stripe; never authorizes payout just because onboarding returned.
- GET `/api/v1/withdrawals/connect/finish`: informational redirect landing; no authentication or verification through redirect.

Enable only with `STRIPE_CONNECT_SELF_SERVICE_ENABLED=true`, existing Stripe LIVE payment configuration and approved platform Connect. Keep `WITHDRAWALS_EXECUTION_ENABLED=false` and `WITHDRAWALS_LIVE_ENABLED=false` until source-transfers, signed webhooks, bank pin approval, payout schedule and anti-duplication checks pass independently.

Account objects created in Stripe are Express v1, and should be validated with your Connect platform settings in TEST before LIVE. Stripe country MX and currency MXN required. Onboarding alone does not settle orders or make a payout; existing manual payout policy persists. The backend may need additional architecture work before fully automatic payout for every new user.
