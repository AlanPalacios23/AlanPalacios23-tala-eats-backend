# TALA EATS Backend 1.6.4 · Código de referencia

**Estado: PREDEPLOY, NO CONSTATADO COMO COPIA IDENTICA A KALI.**

Origen: Archivo de Biblioteca `TALA-EATS-BACKEND-v1.6.4-CONNECT-SELF-SERVICE-SECURITY-HOTFIX1-PREDEPLOY.zip`
SHA-256 origen: `dc0bbf78d16153ed4abf426b75c006c2e8eff903d42d1aea3f8803306fbefa8f`.

Este paquete contiene el código bajo `backend/` (FastAPI, migraciones Alembic, worker, tests, dependencias y Dockerfile) y la nota de release v1.6.4. No contiene `.env*`, credenciales, base de datos, respaldos ni frontend.

La API viva reportó v1.6.4 con ready=true el 13-10-2026, pero esto no prueba igualdad de código. Para certificar paridad exacta, comparar hashes de los archivos contenidos en el contenedor `talaeats-v3-backend-1` contra la release vinculada en Kali. No automatizar deploy ni ejecutar movimientos Stripe LIVE.
